﻿
<div id="footer">
    
<h2>Ждём именно вас!</h2>
<?php
echo date("F j, Y, g:i a"); 
?>


</div>

</body>
</html>